// ==============================================================
// File generated on Wed Nov 15 11:35:20 PST 2023
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:36:41 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================

extern void AESL_WRAP_myproject (
ap_fixed<32, 32, (ap_q_mode) 5, (ap_o_mode)3, 0> input_2[2],
ap_fixed<18, 4, (ap_q_mode) 5, (ap_o_mode)3, 0> layer7_out[1]);

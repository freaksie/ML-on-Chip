//Numpy array shape [4]
//Min -0.269770145416
//Max 0.350173503160
//Number of zeros 0

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
hiddenlayer2_bias_t b4[4];
#else
hiddenlayer2_bias_t b4[4] = {-0.2697701454163, 0.1560648977757, 0.3501735031605, -0.1109162271023};
#endif

#endif

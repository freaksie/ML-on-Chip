//Numpy array shape [1]
//Min -0.119528643787
//Max -0.119528643787
//Number of zeros 0

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
dense_11_bias_t b6[1];
#else
dense_11_bias_t b6[1] = {-0.1195286438};
#endif

#endif

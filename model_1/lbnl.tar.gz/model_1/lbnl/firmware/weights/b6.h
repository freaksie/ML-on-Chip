//Numpy array shape [1]
//Min 0.326010376215
//Max 0.326010376215
//Number of zeros 0

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
ouputlayer_bias_t b6[1];
#else
ouputlayer_bias_t b6[1] = {0.3260103762};
#endif

#endif

//Numpy array shape [8]
//Min -0.161557793617
//Max 0.318197101355
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
hiddenlayer1_bias_t b2[8];
#else
hiddenlayer1_bias_t b2[8] = {0.1538879871, 0.1090544686, 0.2349097729, 0.3181971014, -0.1615577936, -0.0474273339, 0.0378770307, -0.0855487958};
#endif

#endif

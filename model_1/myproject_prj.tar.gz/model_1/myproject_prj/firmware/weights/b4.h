//Numpy array shape [4]
//Min -0.356790482998
//Max 0.581929922104
//Number of zeros 1

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
dense_22_bias_t b4[4];
#else
dense_22_bias_t b4[4] = {-0.3567904830, 0.0000000000, -0.1545361131, 0.5819299221};
#endif

#endif

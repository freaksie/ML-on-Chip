//Numpy array shape [1]
//Min 0.478155553341
//Max 0.478155553341
//Number of zeros 0

#ifndef B6_H_
#define B6_H_

#ifndef __SYNTHESIS__
dense_23_bias_t b6[1];
#else
dense_23_bias_t b6[1] = {0.4781555533};
#endif

#endif

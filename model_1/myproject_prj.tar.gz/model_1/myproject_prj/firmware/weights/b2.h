//Numpy array shape [8]
//Min -0.130119606853
//Max 1.043946266174
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
dense_21_bias_t b2[8];
#else
dense_21_bias_t b2[8] = {-0.0667538643, -0.0723608211, 0.3707067370, 0.1567493230, -0.0149113163, -0.0669412985, 1.0439462662, -0.1301196069};
#endif

#endif

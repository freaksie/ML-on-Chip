//Numpy array shape [8]
//Min -0.767967104912
//Max 0.000000000000
//Number of zeros 4

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
hiddenlayer1_bias_t b2[8];
#else
hiddenlayer1_bias_t b2[8] = {-0.024814065546, -0.711456298828, 0.000000000000, 0.000000000000, 0.000000000000, 0.000000000000, -0.767967104912, -0.696710586548};
#endif

#endif

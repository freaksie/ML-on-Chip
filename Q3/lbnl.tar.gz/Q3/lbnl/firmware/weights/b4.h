//Numpy array shape [4]
//Min -0.587027370930
//Max 0.000000000000
//Number of zeros 1

#ifndef B4_H_
#define B4_H_

#ifndef __SYNTHESIS__
hiddenlayer2_bias_t b4[4];
#else
hiddenlayer2_bias_t b4[4] = {-0.003454852151, -0.540175259113, 0.000000000000, -0.587027370930};
#endif

#endif
